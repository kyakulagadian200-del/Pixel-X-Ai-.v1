# pixelX Ai – real-data version

## What it does
- Live candles from Twelve Data drawn with TradingView Lightweight Charts (the AI reads these same candles)
- Optional full TradingView widget toggle (display only)
- AI analysis in any trading style (Claude), entry/SL/TP drawn on the chart, voice explanation
- Automatic news: Finnhub headlines scored by Claude, no typing needed
- Screenshot upload analyzed by Claude vision
- Position size / risk calculator, paper trades

## Keys you need (all have free tiers except Anthropic)
1. Twelve Data: https://twelvedata.com  -> TWELVEDATA_KEY
2. Finnhub: https://finnhub.io -> FINNHUB_KEY
3. Anthropic: https://console.anthropic.com -> ANTHROPIC_API_KEY

Free Twelve Data plans may not include every index. Edit the SYMBOLS map at the top of server.js to match what your plan allows (or your broker's feed).

## Run locally
    cp .env.example .env    # fill in keys
    node server.js          # open http://localhost:3000

## Put it online (Render.com, free)
1. Upload this folder to a GitHub repo.
2. Render -> New Web Service -> pick the repo. Build command: (empty). Start command: `node server.js`.
3. Add the three keys under Environment. Deploy. Your public URL is your live site.

Keys stay on the server, never in the browser. Real-money execution (MT5/broker) is not included; add it separately and test on a demo account first.
