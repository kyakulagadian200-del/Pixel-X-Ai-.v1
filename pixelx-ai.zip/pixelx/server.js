// pixelX Ai backend: zero dependencies, Node 18+
const http = require('http'), fs = require('fs'), path = require('path');
try { fs.readFileSync('.env','utf8').split('\n').forEach(l => { const m = l.match(/^\s*([A-Z_]+)\s*=\s*(.*)\s*$/); if (m && !process.env[m[1]]) process.env[m[1]] = m[2]; }); } catch {}
const { TWELVEDATA_KEY, FINNHUB_KEY, ANTHROPIC_API_KEY } = process.env;
const MODEL = process.env.CLAUDE_MODEL || 'claude-sonnet-5-5';
// Edit this map to match your data plan. Left = pixelX name, right = Twelve Data symbol.
const SYMBOLS = { 'EUR/USD':'EUR/USD','GBP/USD':'GBP/USD','USD/JPY':'USD/JPY','XAU/USD':'XAU/USD',
  'US30':'DJI','NAS100':'IXIC','SPX500':'SPX','GER40':'DAX' };
const IV = { '1m':'1min','5m':'5min','15m':'15min','1h':'1h','4h':'4h','1D':'1day' };

const json = (res, code, obj) => { res.writeHead(code, {'Content-Type':'application/json'}); res.end(JSON.stringify(obj)); };
const body = req => new Promise(r => { let b=''; req.on('data', c => { b+=c; if (b.length>12e6) req.destroy(); }); req.on('end', () => { try { r(JSON.parse(b||'{}')); } catch { r({}); } }); });

async function candles(sym, tf, n=150) {
  if (!TWELVEDATA_KEY) throw new Error('TWELVEDATA_KEY missing');
  const u = `https://api.twelvedata.com/time_series?symbol=${encodeURIComponent(SYMBOLS[sym]||sym)}&interval=${IV[tf]||'15min'}&outputsize=${n}&order=ASC&timezone=UTC&apikey=${TWELVEDATA_KEY}`;
  const d = await (await fetch(u)).json();
  if (d.status === 'error') throw new Error(d.message);
  return d.values.map(v => ({ time: Math.floor(new Date(v.datetime.replace(' ','T')+'Z')/1000), open:+v.open, high:+v.high, low:+v.low, close:+v.close }));
}
const ema = (a,p) => { const k=2/(p+1); return a.reduce((e,v,i)=> i? v*k+e*(1-k) : v, a[0]); };
function stats(c) {
  const cl=c.map(x=>x.close), last=cl.at(-1);
  const tr=c.slice(-14).map((x,i,a)=> x.high-x.low), atr=tr.reduce((s,v)=>s+v,0)/tr.length;
  let g=0,l=0; cl.slice(-15).forEach((v,i,a)=>{ if(i){ const d=v-a[i-1]; d>0?g+=d:l-=d; }}); const rsi=100-100/(1+(g/(l||1e-9)));
  return { last, ema20:ema(cl,20), ema50:ema(cl,50), rsi:+rsi.toFixed(1), atr, high:Math.max(...c.slice(-50).map(x=>x.high)), low:Math.min(...c.slice(-50).map(x=>x.low)) };
}
async function news(sym) {
  if (!FINNHUB_KEY) throw new Error('FINNHUB_KEY missing');
  const cat = /USD|EUR|GBP|JPY|XAU/.test(sym) && !/^(US30|NAS|SPX|GER)/.test(sym) ? 'forex' : 'general';
  const d = await (await fetch(`https://finnhub.io/api/v1/news?category=${cat}&token=${FINNHUB_KEY}`)).json();
  return (Array.isArray(d)?d:[]).slice(0,12).map(n => ({ headline:n.headline, source:n.source, time:n.datetime, url:n.url }));
}
async function claude(content, system, max=1200) {
  if (!ANTHROPIC_API_KEY) throw new Error('ANTHROPIC_API_KEY missing');
  const r = await fetch('https://api.anthropic.com/v1/messages', { method:'POST',
    headers:{'x-api-key':ANTHROPIC_API_KEY,'anthropic-version':'2023-06-01','content-type':'application/json'},
    body: JSON.stringify({ model:MODEL, max_tokens:max, system, messages:[{role:'user',content}] }) });
  const d = await r.json(); if (d.error) throw new Error(d.error.message);
  return d.content.map(b=>b.text||'').join('');
}
const SYS = 'You are pixelX Ai, a trading analyst for forex and indices. Be concrete and concise. Always remind that this is not financial advice only if asked. Reply ONLY with JSON when a schema is given.';
const parse = t => JSON.parse(t.replace(/```json|```/g,'').trim());

const routes = {
 'GET /api/candles': async (q) => ({ candles: await candles(q.get('symbol'), q.get('tf')) }),
 'GET /api/news': async (q) => ({ news: await news(q.get('symbol')||'EUR/USD') }),
 'POST /api/analyze': async (q, b) => {
   const c = await candles(b.symbol, b.tf), s = stats(c), n = await news(b.symbol).catch(()=>[]);
   const t = await claude(`Symbol ${b.symbol}, timeframe ${b.tf}. Trading style requested by user: "${b.style}". Analyze strictly through that style's concepts.
Indicators: ${JSON.stringify(s)}
Last 60 candles (o,h,l,c): ${JSON.stringify(c.slice(-60).map(x=>[x.open,x.high,x.low,x.close]))}
Recent headlines: ${JSON.stringify(n.slice(0,8).map(x=>x.headline))}
Return JSON: {"bias":"bullish|bearish|neutral","summary":"3-4 sentences","key_levels":{"support":[],"resistance":[]},"signal":{"direction":"BUY|SELL|WAIT","entry":0,"stop_loss":0,"tp1":0,"tp2":0,"tp3":0,"confidence":0},"risk_notes":"1-2 sentences","speech":"short spoken explanation"}`, SYS);
   return { analysis: parse(t), stats: s };
 },
 'POST /api/news-analysis': async (q, b) => {
   const n = await news(b.symbol);
   const t = await claude(`Score these headlines for ${b.symbol}. Headlines: ${JSON.stringify(n.map((x,i)=>[i,x.headline]))}
Return JSON: {"items":[{"i":0,"impact":"bullish|bearish|neutral","strength":1-5,"why":"short"}],"overall":"bullish|bearish|mixed","summary":"2 sentences"}`, SYS, 1500);
   const r = parse(t); return { news:n, scored:r };
 },
 'POST /api/chart-image': async (q, b) => {
   const m = /^data:(image\/\w+);base64,(.+)$/.exec(b.image||''); if (!m) throw new Error('Bad image');
   const t = await claude([{type:'image',source:{type:'base64',media_type:m[1],data:m[2]}},{type:'text',text:`Analyze this trading chart using the "${b.style||'price action'}" approach. Return JSON: {"instrument_guess":"","trend":"","patterns":[],"key_levels":{"support":[],"resistance":[]},"trade_idea":"","risk_notes":"","speech":""}`}], SYS, 1400);
   return { analysis: parse(t) };
 }
};
const MIME = {'.html':'text/html','.js':'text/javascript','.css':'text/css'};
http.createServer(async (req, res) => {
  const u = new URL(req.url, 'http://x'), key = `${req.method} ${u.pathname}`;
  if (routes[key]) { try { json(res, 200, await routes[key](u.searchParams, req.method==='POST'? await body(req):{})); } catch (e) { json(res, 500, { error: e.message }); } return; }
  const f = path.join(__dirname,'public', u.pathname==='/'?'index.html':path.normalize(u.pathname).replace(/^(\.\.[\/\\])+/,''));
  fs.readFile(f, (e,d) => e ? (res.writeHead(404), res.end('Not found')) : (res.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream'}), res.end(d)));
}).listen(process.env.PORT||3000, () => console.log('pixelX Ai running on port '+(process.env.PORT||3000)));
